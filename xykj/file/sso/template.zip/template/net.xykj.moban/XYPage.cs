﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace net.xykj.moban
{
    public class XYPage : System.Web.UI.Page
    {

    }
}
